/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package assignmentone.st10295986;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Amishka
 */
public class AssignmentOneST10295986 {

   public static String userChoice;
    public static String name;
    public static String email;
    public static String course;
    public static int ID;
    public static int age;
       
    final static Scanner kb = new Scanner(System.in); 
    final static ArrayList<Students> students = new ArrayList<>();
                              
    public static void main(String[] args) {
        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.println("*********************************");
        System.out.println("Enter (1) to launch menu or any other key to exist\n");
        userChoice = kb.next();
        
        // now we verifying user input
        if (userChoice.equals("1")) {
            Menu();
//            
        } else {
            System.exit(0);
        } // else ends
    } 
        public static void Menu(){
            // now we indroduce the switch cSE 
        int choice;
        boolean quit = false;
        while (!quit){
            System.out.println("Please select one of the following: \n"
                    + "\n Enter 1 to capture a new student"
                 + "\n Enter 2 to search for a student"
                   + "\n Enter 3 to delete a student"
                   + "\n Enter 5 to exit application");
            choice = kb.nextInt();
            
            switch(choice){
                case 1: Students.saveStudent(students, kb);
                    break;
                case 2:    Students.searchStudent(students, kb);
                    break;
                case 3: Students.deleteStudent(students, kb);
                    break;
                case 4: Students.studentReport();
                    break;
                case 5: 
                    break;
                default: System.out.println("Invalid entry, enter the correct information");    
                    break;
            }
       }
        } // end of menu()
        
        
    
    
     
    
    } // main ends

        
 
        
        
        
        
        
        
        
        
        
        
     
        
        
        
        
    
 