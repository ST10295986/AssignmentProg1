/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignmentone.st10295986;

import java.util.ArrayList;
import java.util.Scanner;


/**
 *
 * @author Amishka
 */
public class Students {
   

public static String name;
public static String email;
public static String course;
public static int ID;
public static int age;

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getCourse() {
        return course;
    }

    public int getID() {
        return ID;
    }

    public int getAge() {
        return age;
    }

    public ArrayList<Students> getStudents() {
        return students;
    }


// the constructor
    public Students(String name, String email, String course, int ID, int age, ArrayList<Students> students) {
        this.name = name;
        this.email = email;
        this.course = course;
        this.ID = ID;
        this.age = age;
        this.students = students;
    }
    

     final static Scanner kb = new Scanner(System.in);  
       
     //now we have to make use of our array list for each varibale --> private static
       private final ArrayList<Students> students;
       
      public static void saveStudent(ArrayList<Students> students, Scanner kb){
          System.out.println("Enter the student ID");
        ID = Integer.parseInt(kb.next());
        System.out.println("Enter the student name");
        name = kb.next();
        
        System.out.println("Enter the student age");
        int Age =kb.nextInt();
       // preferred use of an 'if else statement' to verify age from the start
          if (Age < 16)  {
              System.out.println("Invalid age, please re-enter age");
              return;
          } 
        System.out.println("Enter the student email");
        email = kb.next();
        
        System.out.println("Enter the student course");
        course = kb.next(); 
        // adding the names to store and then to be pressented
       // name.add(ID);
        
          System.out.println("Student added successfully!");
      } // end of save student method
      
      public static void searchStudent(ArrayList<Students> students, Scanner kb) {
          System.out.println("Enter the student ID to search");
        int ID = kb.nextInt();
         boolean found = false;
                 for(Students student : students){
            if(student.getID()== ID){
                found = true;
                System.out.println("Student found:");
            System.out.println("ID: " + student.getID());
            System.out.println("Name: " + student.getName());
            System.out.println("Age: " + student.getAge());
            System.out.println("Email: " + student.getEmail());
            System.out.println("Course: " + student.getCourse());
            break; 
            } 
         }// for loop ends
         if(!found) {
             System.out.println("Student with ID:" + ID + " does not exist.");
         }
      } // search student () ends
       
      public static void deleteStudent(ArrayList<Students> students, Scanner kb) {
          System.out.println("Please enter student ID to delete:");
          int deleteStudent = kb.nextInt();
          int indexToRemove = -1;
          for (int i = 0; i < students.size(); i++) {
            if (students.get(i).getID() ==ID) {
                indexToRemove = i;
                break;
            }
        }
if (indexToRemove != -1) {
            students.remove(indexToRemove);
            System.out.println("Student with ID: " + ID + " was successfully deleted.");
        } else {
            System.out.println("Student with ID: " + ID + " does not exist.");
        }
    }
      public static void studentReport(){
          System.out.println("--------------------------");
          System.out.println("Student ID: " + ID);
        System.out.println("Student Name: " + name);
        System.out.println("Student Age: " + age);
        System.out.println("Student Email: " + email);
        System.out.println("Student Course: " + course);
          System.out.println("------------------------------");
    }
    

      
      
}// main ends