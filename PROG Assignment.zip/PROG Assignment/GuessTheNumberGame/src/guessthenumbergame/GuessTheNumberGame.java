/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package guessthenumbergame;

import java.util.Scanner;

/**
 *
 * @author Amishka
 */
public class GuessTheNumberGame {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Question 2 of assignment
         Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to Guess the Number Game!");
        System.out.println("Enter the maximum range for the game:");

        int maxRange = scanner.nextInt();
        if (maxRange <= 0) {
            System.out.println("Invalid range. Please enter a positive number.");
            return;
        }

        // Create a game instance
        NumberGame game = new NumberGame(maxRange);

        //  user will play the game in this part
        boolean isGameOver = false;
        while (!isGameOver) {
            System.out.println("Enter your guess:");
            int userGuess = scanner.nextInt();
            String result = game.checkGuess(userGuess);
            System.out.println(result);
            if (result.equals("Congratulations! You guessed the number.")) {
                isGameOver = true;
            }
        }
        scanner.close();
    }
  
    
}
