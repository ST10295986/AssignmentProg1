/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guessthenumbergame;

import java.util.Random;

/**
 *
 * @author Amishka
 */
public class NumberGame {
     private final int secretNumber;
    private boolean isGameOver;

    public int getSecretNumber() {
        return secretNumber;
    }

    public boolean isIsGameOver() {
        return isGameOver;
    }
//constructor + methods
    public NumberGame(int maxRange) {
        Random rand = new Random();
        this.secretNumber = rand.nextInt(maxRange) + 1;
        this.isGameOver = false;
    }

    public String checkGuess(int userGuess) {
        if (isGameOver) {
            return "The game is already over. Start a new game.";
        }

        if (userGuess == secretNumber) {
            isGameOver = true;
            return "Congratulations! You guessed the number.";
        } else if (userGuess < secretNumber) {
            return "Try a higher number.";
        } else {
            return "Try a lower number.";
        }
    }
}
