/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package guessthenumbergame;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Amishka
 */
public class NumberGameTest {
    
    public NumberGameTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of checkGuess method, of class NumberGame.
     */
    @Test
    public void testCheckGuess() {
        System.out.println("checkGuess");
        int userGuess = 0;
        NumberGame instance = null;
        String expResult = "";
        String result = instance.checkGuess(userGuess);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
     @Test
    public void testCorrectGuess() {
        NumberGame game = new NumberGame(100);
        String result = game.checkGuess(game.getSecretNumber());
        assertEquals("Congratulations! You guessed the number.", result);
    }

    @Test
    public void testHigherGuess() {
        NumberGame game = new NumberGame(100);
        String result = game.checkGuess(game.getSecretNumber() - 1);
        assertEquals("Try a higher number.", result);
    }

    @Test
    public void testLowerGuess() {
        NumberGame game = new NumberGame(100);
        String result = game.checkGuess(game.getSecretNumber() + 1);
        assertEquals("Try a lower number.", result);
    }

    @Test
    public void testGameAlreadyOver() {
        NumberGame game = new NumberGame(100);
        game.checkGuess(game.getSecretNumber());
        String result = game.checkGuess(game.getSecretNumber() + 1);
        assertEquals("The game is already over. Start a new game.", result);
    }
}
