/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package assignmentone.st10295986;

import static assignmentone.st10295986.AssignmentOneST10295986.students;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Scanner;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Amishka
 */
public class StudentsTest {
    
    public StudentsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
      
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of saveStudent method, of class Students.
     */
    @Test
    public void testSaveStudent() {
           ArrayList<Students> studentList = new ArrayList<>();

        // Simulate user input using a ByteArrayInputStream
        String input = "1,John,18,john@example.com,Art";
        System.setIn(new ByteArrayInputStream(input.getBytes()));

        // Call the saveStudent method
        Students.saveStudent(studentList, new Scanner(System.in));

        // Check if the student has been added to the list
        assertEquals(1, studentList.size());
        Students student = studentList.get(0);
        assertEquals(1, student.getID());
        assertEquals("John", student.getName());
        assertEquals(18, student.getAge());
        assertEquals("john@example.com", student.getEmail());
        assertEquals("Art", student.getCourse());
    }

    /**
     * Test of searchStudent method, of class Students.
     */
    @Test
    public void testSearchStudent() {
         // Prepare input for scanner
        String input = "2\n";  // Search for student with ID 2
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        Scanner kb = new Scanner(System.in);

        // Call the searchStudent method
         Students.searchStudent(students, kb);

        // Reset System.in to its original value
        System.setIn(System.in);

        // Perform assertions
        // You might need to adapt these assertions based on your Students class
        assertTrue(true); // You can add assertions for the output if needed
    }
    
    @Test
    public void testSearchStudentNotFound() {
        // Prepare input for scanner
        String input = "4\n";  // Search for a non-existent student with ID 4
        System.setIn(new ByteArrayInputStream(input.getBytes()));

      
        Scanner kb = new Scanner(System.in);

        // Call the searchStudent method
        Students.searchStudent(students, kb);

        // Reset System.in to its original value
        System.setIn(System.in);

        
        assertTrue(true); 
    }


    /**
     * Test of deleteStudent method, of class Students.
     */
    @Test
    public void testDeleteStudent() {
        String input = "2\n";  // Delete student with ID 2
        System.setIn(new ByteArrayInputStream(input.getBytes()));

        // Create a new scanner
        Scanner kb = new Scanner(System.in);

        // Call the deleteStudent method
        Students.deleteStudent(students, kb);

        // Reset System.in to its original value
        System.setIn(System.in);

       
        assertEquals(2, students.size()); 
    }

    @Test
    public void testDeleteStudentNotFound() {
        // Prepare input for scanner
        String input = "4\n";  // Delete a non-existent student with ID 4
        System.setIn(new ByteArrayInputStream(input.getBytes()));

        // Create a new scanner
        Scanner kb = new Scanner(System.in);

        // Call the deleteStudent method
        Students.deleteStudent(students, kb);

        // Reset System.in to its original value
        System.setIn(System.in);

        // Perform assertions
        assertEquals(3, students.size()); // Verify that the student list size is unchanged
    }
    public void testValidAge() {
        // Prepare input for scanner
        String input = "18\n";  // Valid age (>= 16)
        System.setIn(new ByteArrayInputStream(input.getBytes()));

        // Create a new scanner
        Scanner kb = new Scanner(System.in);

        // Call the code that validates the age
       // Students.validateAge(kb);  // Replace YourClassName with the actual class name

       
    }

  
}
